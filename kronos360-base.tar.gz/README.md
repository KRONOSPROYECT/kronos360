# KRONOS 360

Base de proyecto para una plataforma de evidencias digitales con arquitectura **crypto-agile** y plan de migración poscuántica.

> Este repositorio es un MVP técnico. No constituye una certificación legal, una auditoría de seguridad ni una promesa de seguridad absoluta. Antes de producción se requiere revisión independiente, gestión segura de claves y selección de implementaciones criptográficas aprobadas.

## Objetivo del MVP

- Canonizar registros de forma determinista.
- Calcular huellas SHA3-512.
- Crear y verificar registros de evidencia.
- Mantener metadatos de política criptográfica y versiones.
- Representar firmas híbridas clásicas y poscuánticas mediante adaptadores.
- Crear evidencias de migración sin sobrescribir registros históricos.
- Probar el núcleo sin depender inicialmente de un proveedor externo.

## Estado de la criptografía

El núcleo implementa hashes y un adaptador de firma **demo** para desarrollo. El adaptador demo no debe utilizarse para proteger certificados reales. La integración de ECDSA/ML-DSA debe conectarse a bibliotecas mantenidas, revisadas y aprobadas por el equipo de seguridad antes de producción.

## Inicio rápido

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e '.[dev]'
pytest
python -m kronos360.cli demo
```

## Estructura

```text
src/kronos360/
├── crypto/          canonización, hash y adaptadores de firma
├── models/          modelos serializables de evidencia
├── services/        emisión, verificación y migración
└── cli.py           demostración local
```

## Principios de seguridad

1. Nunca guardar claves privadas en Git, logs o ejemplos.
2. Separar hash, firma, clave pública, política y evidencia temporal.
3. No sobrescribir evidencias históricas.
4. Rechazar algoritmos desconocidos en producción.
5. Tratar la canonización como parte del protocolo versionado.
6. No confundir hash con firma digital.
7. Revisar legalmente toda afirmación sobre autoría, fecha o validez.

## Próximas integraciones

- Implementación real de ECDSA y ML-DSA mediante proveedores aprobados.
- HSM/KMS.
- API FastAPI y persistencia PostgreSQL.
- Autoridad de sellado de tiempo.
- Revocación y rotación de claves.
- Auditoría inmutable.
- Migración masiva por lotes.

Consulta `docs/architecture.md`, `docs/migration-plan.md` y `docs/security.md` para el diseño detallado.
